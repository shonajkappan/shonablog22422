import "./header.css"

export default function Header() {
  return (
    <div className="header">
        <div className="headerTitles">
            <span className="headerTitlesLg"> Blog byShona</span>
        </div>
        <img className="headerImg" src="https://cdn.mos.cms.futurecdn.net/CAZ6JXi6huSuN4QGE627NR.jpg" alt="" />
    </div>
  )
}
