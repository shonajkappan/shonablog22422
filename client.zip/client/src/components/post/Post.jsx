import "./post.css"
import { Link } from 'react-router-dom';
import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { useLocation } from "react-router";
import Comments from "../comment/Comment"
import Comment from "../comment/Comment"


export default function Post({post}) {
  
  const PF = "http://localhost:5000/images/";

  const [count, setCount] = useState(0);
  const [calculation, setCalculation] = useState(0);

  useEffect(() => {
    setCalculation(() => count * 2);
  }, [count]); // <- add the count variable here

  const [comments, setComments]=useState([]);
  const { search } = useLocation();
  useEffect(()=>{
    const fetchComments= async ()=>{
      const res = await axios.get("/comments" + search);
      setComments(res.data)
    }
    fetchComments()
  },[search])
  console.log({comments})
  
  
  return (
    <div className="post">
      {post.photo && <img className="postImg" src={PF + post.photo} alt="" />}
      <div className="postInfo">
        <div className="postCats">
          {post.categories.map((c) => (
            <span className="postCat">{c.name}</span>
          ))}
        </div>
        <Link to={`/post/${post._id}`} className="link">
          <span className="postTitle">{post.title}</span>
        </Link>
        <hr />
        <span className="postDate">
          {new Date(post.createdAt).toDateString()}
        </span>
      </div>
      <p className="postDesc">{post.desc}</p>
      <div className="commentHeader">Comments
    
      </div>
      <div >

      {comments.map((p) => (
      <Comment comment={p}/>

      ))}

    </div>
    </div>
  );
}