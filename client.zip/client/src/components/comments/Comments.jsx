import Comment from "../comment/Comment"
import "./comments.css"

export default function Comments({ comments }) {
  return (
    <div className="posts">
      
      {comments.map((p) => (
        <Comment comment={p}/>

      ))}
      
      
     
    
    </div>
  );
}
