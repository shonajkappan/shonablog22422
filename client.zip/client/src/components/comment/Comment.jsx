import "./comment.css"
import { Link } from 'react-router-dom';
export default function Comment({comment}) {
  const PF = "http://localhost:5000/images/";
  return (
    <div >
    
      <div className="postInfo">
       <span className="postTitle">{comment.title}</span>
        
       <span className="postDate">
          {new Date(comment.createdAt).toDateString()}
        </span>
      </div>
      <p className="postDesc"> {comment.desc}</p>
    </div>
  );
}